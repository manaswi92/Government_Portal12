GovCareer assets folder.
logo.svg - site logo (also used as favicon).
All job, exam and result records in this project are DEMO DATA for a college project.
Always verify recruitment details on the relevant official website.
